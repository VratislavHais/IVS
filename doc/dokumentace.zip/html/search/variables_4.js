var searchData=
[
  ['isresult',['isResult',['../namespacecalculator.html#a670c7641ebdabe9d8fad5263f0c16097',1,'calculator']]],
  ['items',['items',['../classcalculator_1_1Stack.html#aecba6988abaf4eaba95d067208df8c51',1,'calculator::Stack']]]
];

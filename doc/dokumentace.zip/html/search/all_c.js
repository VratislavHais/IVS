var searchData=
[
  ['negation',['negation',['../namespacecalculator.html#ab5ce12eed690702295b4cb27d622bacb',1,'calculator']]]
];

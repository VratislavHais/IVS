var searchData=
[
  ['pop',['pop',['../classcalculator_1_1Stack.html#a6f823b69e1d2d02fec02c26fcddbb18f',1,'calculator::Stack']]],
  ['push',['push',['../classcalculator_1_1Stack.html#a5e258651ed0f04acfd51fa41c1b8c65d',1,'calculator::Stack']]]
];

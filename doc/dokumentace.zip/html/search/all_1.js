var searchData=
[
  ['appendtext',['appendText',['../namespacecalculator.html#ac1e4558e3fb89261eed072f57f48e8e1',1,'calculator']]]
];

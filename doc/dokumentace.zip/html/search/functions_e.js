var searchData=
[
  ['remove',['remove',['../classcalculator_1_1Stack.html#add092ff704fe101a65e8e2e0278cc60d',1,'calculator::Stack']]]
];

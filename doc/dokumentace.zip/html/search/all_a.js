var searchData=
[
  ['label',['label',['../namespacecalculator.html#a1bfe603232d341643169925052fd1be5',1,'calculator']]]
];

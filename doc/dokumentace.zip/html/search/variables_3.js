var searchData=
[
  ['height',['height',['../namespacecalculator.html#aadc28eb8d55611ea0eb90e5aaabae70f',1,'calculator']]],
  ['hexbuttons',['hexButtons',['../namespacecalculator.html#af4fa0938710315c3e77750fa3ec2c906',1,'calculator']]]
];

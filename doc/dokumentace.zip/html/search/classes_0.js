var searchData=
[
  ['stack',['Stack',['../classcalculator_1_1Stack.html',1,'calculator']]]
];

var searchData=
[
  ['calculatebmi',['calculateBMI',['../namespacecalculator.html#ab6d7d083dbbd490327e983f6772e71ae',1,'calculator']]],
  ['clear',['clear',['../classcalculator_1_1Stack.html#aa02eaa21893381c11715273f59c8531a',1,'calculator.Stack.clear()'],['../namespacecalculator.html#add79650bc05d6631b829cbfff7bcabe4',1,'calculator.clear()']]]
];

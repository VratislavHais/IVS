var searchData=
[
  ['basic',['basic',['../namespacecalculator.html#a8bf9ebe861d9eba743ee1b11fd9798b3',1,'calculator']]],
  ['binary',['binary',['../namespacecalculator.html#ae57cee6da6f9156b40ce88917b491771',1,'calculator']]],
  ['bodymassindex',['bodyMassIndex',['../namespacecalculator.html#a098b077776a173d9f65b7f40f417248d',1,'calculator']]]
];

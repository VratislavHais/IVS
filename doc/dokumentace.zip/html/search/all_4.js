var searchData=
[
  ['decimal',['decimal',['../namespacecalculator.html#ab3a2bd938c7ebc0bbe4a881ee5fd1e86',1,'calculator']]],
  ['delete',['delete',['../namespacecalculator.html#aaae0829b13324702ca3dce40afce123b',1,'calculator']]]
];

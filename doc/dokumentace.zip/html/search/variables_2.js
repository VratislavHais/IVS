var searchData=
[
  ['false',['False',['../namespacecalculator.html#a802521373f7b4ce1a92bc002741dd582',1,'calculator']]]
];
